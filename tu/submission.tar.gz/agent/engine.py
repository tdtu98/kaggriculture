"""Scripted economic engine (T1.1-T1.4, seed version).

Structure: each turn, generate the task list from farm state, assign tasks to units by distance
with deadline priority, and emit one op per unit. Market orders are decided separately.

Deliberately *not* a per-turn reflex agent — the task/assignment split is what T3 will keep when
the model replaces the task *selection* while the executor keeps doing the routing.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

# The reference environment's own pricing function, not a copy: it is exact by construction
# (including Python's banker's rounding), it honours `marketParams` overrides, and it exists on
# the Kaggle runner — where `kagsim` does not.
from kaggle_environments.envs.kaggriculture.kaggriculture import (
    ANIMALS,
    CROPS,
    SHOPS,
    TOWN_CENTER_PRODUCTS,
    market_price,
)

from .params import Params

SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
BASE_PRICE = {"WHEAT": 25, "CARROT": 35, "TOMATO": 60, "STRAWBERRY": 120, "MELON": 250,
              "EGG": 50, "MILK": 160, "WOOL": 200, "FERTILIZER": 100}
PRODUCT_IDX = {p: i for i, p in enumerate(BASE_PRICE)}
ANIMAL_PRODUCT = {"GOOSE": "EGG", "COW": "MILK", "SHEEP": "WOOL"}
# Which structure each species needs. Every animal yields 1 fertilizer/day regardless of species
# and regardless of feeding (`kaggriculture.py:809`), so the species choice is really a choice of
# secondary product on top of a common fertilizer stream.
ANIMAL_STRUCTURE = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}
BUILD_OP = {"COOP": "BUILD_COOP", "PASTURE": "BUILD_PASTURE"}


@dataclass
class Task:
    x: int
    y: int
    op: str
    arg: str | None
    prio: int          # lower runs first
    needs: str | None = None   # item the unit must already be carrying
    n: int | None = None       # quantity, for PICKUP


def _harvest_day(crop: str, params: Params) -> int:
    c = CROPS[crop]
    if params.harvest_early:
        return c["first_yield_day"]
    if crop == "MELON":
        return 10   # yield caps at 6 by age 10; ages 11-12 add nothing
    return c["max_yield_day"]


def _needs_water(tile: dict, day: int) -> bool:
    """Water to survive (death is at 2 consecutive misses) or to earn the in-window bonus."""
    if tile["watered_today"]:
        return False
    if tile["consecutive_unwatered"] >= 1:
        return True
    c = CROPS[tile["crop"]]
    if c["ongoing"]:
        return False
    age = day - tile["planted_day"]
    return (c["max_yield_day"] + 1) // 2 <= age <= c["max_yield_day"]


class Engine:
    """Stateful agent. One instance per player per episode."""

    def __init__(self, params: Params | None = None):
        self.p = params or Params()
        self._day = -1
        # Sticky per-unit assignments. Without these the greedy nearest-task choice is recomputed
        # every turn, so a unit walking toward A flips to B as soon as B becomes marginally
        # closer, and can oscillate forever without arriving anywhere.
        self._assigned: dict[int, tuple[int, int, str, str | None, int | None]] = {}

    # ------------------------------------------------------------------ tasks

    def build_tasks(self, farm: dict, priv: dict, day: int) -> list[Task]:
        p = self.p
        tiles = farm["tiles"]
        tasks: list[Task] = []
        n_animals = 0
        n_plants = 0
        empty: list[tuple[int, int]] = []
        empty_coops_by_kind: dict[str, list[tuple[int, int]]] = {"COOP": [], "PASTURE": []}

        feed_today = True
        if p.feed_alternate:
            # A newly placed animal survives day 0 unfed but must eat on day 1, so feed on odd days.
            feed_today = day % 2 == 1

        for y, row in enumerate(tiles):
            for x, t in enumerate(row):
                if t == "LOCKED":
                    continue
                if t is None:
                    empty.append((x, y))
                    continue
                kind = t.get("kind")
                if kind == "WEED":
                    tasks.append(Task(x, y, "DIG", None, 6))
                elif kind == "PLANT":
                    n_plants += 1
                    age = day - t["planted_day"]
                    c = CROPS[t["crop"]]
                    ready = t["yield_units"] > 0 and age >= c["first_yield_day"]
                    if ready and (c["ongoing"] or age >= _harvest_day(t["crop"], p)):
                        tasks.append(Task(x, y, "HARVEST", None, 1))
                    elif _needs_water(t, day):
                        tasks.append(Task(x, y, "WATER", None, 0))
                elif "animal" in t:
                    n_animals += 1
                    if t["yield_units"] > 0:
                        tasks.append(Task(x, y, "HARVEST", None, 1))
                    if t["fertilizer_available"]:
                        tasks.append(Task(x, y, "COLLECT_FERTILIZER", None, 3))
                    if feed_today and not t["fed_today"]:
                        tasks.append(Task(x, y, "FEED", None, 0, needs="WHEAT"))
                    if p.care and not p.feed_alternate and not t["cared_today"]:
                        tasks.append(Task(x, y, "CARE", None, 4))
                else:  # an empty structure — kind decides which species can go on it
                    empty_coops_by_kind[t.get("kind", "COOP")].append((x, y))

        # Wheat fetching. Without this, FEED is permanently unassignable (`needs="WHEAT"` and no
        # unit ever carries any), so every animal placed starves within two days.
        unfed = sum(1 for t in tasks if t.op == "FEED")
        if unfed:
            carried = sum(i.get("WHEAT", 0) for i in priv["inventories"])
            shed_wheat = priv["shed"].get("WHEAT", 0)
            short = min(unfed - carried, shed_wheat)
            per_trip = max(1, min(p.feed_batch, short))
            trips = math.ceil(short / per_trip) if short > 0 else 0
            for k in range(min(trips, len(SHED_TILES))):
                x, y = SHED_TILES[k]
                tasks.append(Task(x, y, "PICKUP", "WHEAT", 0, n=per_trip))

        # --- animals: build structures, fetch stock, place it -------------------------------
        targets = {"GOOSE": p.goose_target, "COW": p.cow_target, "SHEEP": p.sheep_target}
        placed = {a: 0 for a in targets}
        for row in farm["tiles"]:
            for t in row:
                if isinstance(t, dict) and t.get("animal"):
                    placed[t["animal"]] = placed.get(t["animal"], 0) + 1

        free_struct = {"COOP": list(empty_coops_by_kind["COOP"]),
                       "PASTURE": list(empty_coops_by_kind["PASTURE"])}
        # Nearest-first, and animals get first pick. Measured: structures were being placed from
        # the raw row-major list while *crops* took the nearest tiles — exactly inverted. An animal
        # needs a wheat fetch from the shed almost every day, so its distance is paid daily; a crop
        # needs watering, which requires no shed trip at all. Animals sat at mean distance 7.1 and
        # movement was 65% of every unit's turns.
        remaining_empty = self._nearest_first(list(empty))

        for animal, target in targets.items():
            if target <= 0:
                continue
            struct = ANIMAL_STRUCTURE[animal]
            in_shed = priv["shed"].get(animal, 0)
            carried = sum(i.get(animal, 0) for i in priv["inventories"])

            # Place stock we already hold onto a free structure of the right kind.
            n_place = min(len(free_struct[struct]), in_shed + carried)
            for _ in range(n_place):
                x, y = free_struct[struct].pop(0)
                tasks.append(Task(x, y, "PLACE", animal, 2, needs=animal))

            # Fetch from the shed. PLACE is gated on already carrying the animal, and without this
            # nothing ever collects one — the defect that left coops empty for nine days.
            short = min(in_shed, len(free_struct[struct]) - carried)
            if in_shed > 0 and short > 0:
                x, y = SHED_TILES[0]
                tasks.append(Task(x, y, "PICKUP", animal, 1, n=short))

            # Build what is still missing, cheapest structure first come first served.
            want = max(0, target - placed[animal] - len(free_struct[struct]))
            for _ in range(min(want, len(remaining_empty))):
                x, y = remaining_empty.pop(0)
                tasks.append(Task(x, y, BUILD_OP[struct], None, 5))

        # Cap standing crops at what the labour force can actually keep watered. Planting past
        # this point is worse than leaving the tile idle: an unwatered plant becomes a weed, which
        # then costs a DIG to clear.
        n_units = 1 + p.hire_max
        budget = max(0, int(n_units * p.tiles_per_unit) - n_plants)
        remaining_empty = self._nearest_first(remaining_empty)[:budget]

        for (x, y), crop in zip(remaining_empty, self._plant_queue(priv, len(remaining_empty))):
            tasks.append(Task(x, y, "PLANT", crop, 5))

        return tasks

    @staticmethod
    def _nearest_first(cells: list[tuple[int, int]]) -> list[tuple[int, int]]:
        """Prefer tiles near the shed — units respawn there daily, so travel dominates cost."""
        return sorted(cells, key=lambda c: abs(c[0] - 4.5) + abs(c[1] - 4.5))

    def _plant_queue(self, priv: dict, n: int) -> list[str]:
        """Crops to plant, limited by seeds actually on hand."""
        mix = {k: v for k, v in self.p.crop_mix.items() if v > 0}
        if not mix:
            return []
        total = sum(mix.values())
        out: list[str] = []
        for crop, w in sorted(mix.items(), key=lambda kv: -kv[1]):
            want = min(int(round(n * w / total)) + 1, priv["seeds"].get(crop, 0))
            out.extend([crop] * want)
        return out[:n]

    # ------------------------------------------------------------- assignment

    def assign(self, units: list[tuple[int, int]], tasks: list[Task], invs: list[dict]) -> list[list]:
        """Sticky greedy assignment: keep last turn's target while it is still a live task."""
        actions: list[list] = []
        p_weight = self.p.priority_weight
        taken: set[int] = set()
        by_key = {(t.x, t.y, t.op, t.arg, t.n): ti for ti, t in enumerate(tasks)}

        # Honour existing assignments first so units actually finish the walk they started.
        keep: dict[int, int] = {}
        for idx in range(len(units)):
            prev = self._assigned.get(idx)
            if prev is None:
                continue
            ti = by_key.get(prev)
            inv = invs[idx] if idx < len(invs) else {}
            if ti is None or ti in taken:
                self._assigned.pop(idx, None)
                continue
            if tasks[ti].needs and inv.get(tasks[ti].needs, 0) <= 0:
                self._assigned.pop(idx, None)
                continue
            keep[idx] = ti
            taken.add(ti)

        for idx, (ux, uy) in enumerate(units):
            inv = invs[idx] if idx < len(invs) else {}
            ti = keep.get(idx)
            if ti is None:
                best, best_key = None, None
                for cand, t in enumerate(tasks):
                    if cand in taken:
                        continue
                    if t.needs and inv.get(t.needs, 0) <= 0:
                        continue
                    # Distance and priority on one scale: a task `priority_weight` tiles further
                    # away must be a whole priority level more urgent to be worth the walk.
                    key = (abs(t.x - ux) + abs(t.y - uy)) + p_weight * t.prio
                    if best_key is None or key < best_key:
                        best, best_key = cand, key
                if best is None:
                    self._assigned.pop(idx, None)
                    actions.append(self._fallback(ux, uy, inv, tasks))
                    continue
                ti = best
                taken.add(ti)
            t = tasks[ti]
            self._assigned[idx] = (t.x, t.y, t.op, t.arg, t.n)
            if (ux, uy) != (t.x, t.y):
                actions.append(self._step_toward(ux, uy, t.x, t.y))
            else:
                self._assigned.pop(idx, None)   # arriving completes it
                if t.n is not None:
                    actions.append([t.op, t.arg, t.n])
                elif t.arg:
                    actions.append([t.op, t.arg])
                else:
                    actions.append([t.op])
        return actions

    def _fallback(self, ux: int, uy: int, inv: dict, tasks: list[Task]) -> list:
        """Nothing assignable: fetch an item a blocked task needs, or dump what we're carrying."""
        wanted = next((t.needs for t in tasks if t.needs and inv.get(t.needs, 0) <= 0), None)
        at_shed = (ux, uy) in SHED_TILES
        if wanted:
            if at_shed:
                return ["PICKUP", wanted, 4]
            return self._step_toward(ux, uy, 4, 4)
        if inv and at_shed:
            return ["DROP"]
        if inv:
            return self._step_toward(ux, uy, 4, 4)
        return ["PASS"]

    @staticmethod
    def _step_toward(ux: int, uy: int, tx: int, ty: int) -> list:
        if ux < tx:
            return ["EAST"]
        if ux > tx:
            return ["WEST"]
        if uy < ty:
            return ["SOUTH"]
        if uy > ty:
            return ["NORTH"]
        return ["PASS"]

    # --------------------------------------------------------------- forecast

    def opponent_supply(self, obs: dict, me: int) -> dict[str, int]:
        """Units of each product the opponent will harvest within `forecast_horizon` days.

        Their farm is public (`farms` is shared) and crop maturity is deterministic, so their
        entire production schedule is computable. Their *shed* is private, so this is incoming
        supply only — not stock they may already be sitting on.
        """
        opp = 1 - me
        farm = obs["farms"][opp]
        day = obs["day"]
        horizon = self.p.forecast_horizon
        out: dict[str, int] = {}

        for row in farm["tiles"]:
            for t in row:
                if not isinstance(t, dict):
                    continue
                if t.get("kind") == "PLANT":
                    c = CROPS[t["crop"]]
                    age = day - t["planted_day"]
                    ready_at = c["first_yield_day"] if c["ongoing"] else _harvest_day(t["crop"], self.p)
                    eta = ready_at - age
                    if eta <= horizon:
                        # Already-accumulated units can be sold immediately; otherwise assume the
                        # crop is taken to its cap, which is what any competent agent does.
                        units = t["yield_units"] if eta <= 0 else c["max_yield"]
                        out[t["crop"]] = out.get(t["crop"], 0) + units
                elif "animal" in t:
                    p = ANIMAL_PRODUCT[t["animal"]]
                    a = ANIMALS[t["animal"]]
                    produced = t["yield_units"] + max(0, horizon // max(1, a["interval"]))
                    out[p] = out.get(p, 0) + produced
        return out

    @staticmethod
    def town_drain_per_day(obs: dict) -> dict[str, int]:
        """How much the town removes per day, which is what lets a crashed price recover.

        Assumes the default intervals (24 turns/day, shops every 4 turns, centre every 12): the
        environment configuration is not exposed in the observation.
        """
        drain: dict[str, int] = {}
        for shop in obs["town"]["unlocked_shops"]:
            products = SHOPS[shop]
            mult = 2 if len(products) == 1 else 1
            for item in products:
                drain[item] = drain.get(item, 0) + mult * 6      # 6 ticks/day
        centre = 4 if obs["day"] >= 20 else 2 if obs["day"] >= 10 else 1
        for item in TOWN_CENTER_PRODUCTS:
            drain[item] = drain.get(item, 0) + centre * 2        # 2 ticks/day
        return drain

    def forecast_price(self, item: str, inv: dict, supply: dict, drain: dict,
                       params: dict | None = None) -> float:
        """Price we expect once the opponent's wave lands and the town has drained a little."""
        h = self.p.forecast_horizon
        future = inv[item] + supply.get(item, 0) - drain.get(item, 0) * h
        return float(market_price(item, max(0, future), params))

    # ----------------------------------------------------------------- market

    def market(self, obs: dict, farm: dict, priv: dict, day: int, hour: int) -> list[list]:
        """Spend against an explicit budget, in ROI order, within the 10-slot cap.

        Two things drive the ordering:

        * **Sells go first.** `_process_market` commits order slots sequentially, so proceeds from
          a SELL in slot 0 are available to fund a BUY in a later slot *within the same turn*.
        * **Cheap, fast-payback purchases outrank expensive, slow ones.** Seeds are working capital
          that recycles in 4-5 days; land is a $1k-$4k outlay that only pays off if the labour
          exists to work it. Buying land first is exactly what starved the engine of seed money and
          invalidated the goose experiment (docs/experiments.md E3).
        """
        p = self.p
        inv = obs["market"]["inventory"]
        tiles = [t for row in farm["tiles"] for t in row]
        n_animals = sum(1 for t in tiles if isinstance(t, dict) and "animal" in t)
        n_structs = sum(
            1 for t in tiles
            if isinstance(t, dict) and t.get("kind") in ("COOP", "PASTURE") and "animal" not in t
        )
        empty = sum(1 for t in tiles if t is None)

        orders: list[list] = []

        # 1. Sell first — the proceeds fund everything below, this same turn.
        feed_reserve = (n_animals + n_structs) * p.wheat_reserve_per_animal
        # `marketParams` overrides land in the shared observation; without threading them through,
        # every price the engine reasons about is wrong whenever the episode overrides a curve.
        mparams = obs["market"].get("params")
        sells = self._sell_orders(priv, inv, day, feed_reserve, obs)[:3]
        orders += sells
        money = farm["money"] + sum(
            self._estimate_proceeds(o[1], o[2], inv, mparams) for o in sells)

        def afford(cost: float, extra_reserve: float = 0.0) -> bool:
            nonlocal money
            if money - cost < p.cash_floor + extra_reserve:
                return False
            money -= cost
            return True

        def buy_animals():
            """One purchase pass per species, cheapest-first.

            Every animal yields 1 fertilizer/day regardless of species and regardless of feeding,
            so a bird and a cow share that stream; the species differs only in the secondary
            product and in price ($300 / $400 / $500). Whether the dearer species ever pays is a
            measurement, not an assumption — cows and sheep were simply unbuildable before V3.
            """
            for animal in ("GOOSE", "COW", "SHEEP"):
                target = {"GOOSE": p.goose_target, "COW": p.cow_target,
                          "SHEEP": p.sheep_target}[animal]
                if target <= 0:
                    continue
                carried = sum(i.get(animal, 0) for i in priv["inventories"])
                have = sum(1 for row in farm["tiles"] for t in row
                           if isinstance(t, dict) and t.get("animal") == animal)
                owned = have + priv["shed"].get(animal, 0) + carried
                room = n_structs + empty
                if owned >= target or room <= 0:
                    continue
                cost = ANIMALS[animal]["cost"]
                want = min(target - owned, room, 2)
                n = 0
                while n < want and afford(cost, p.goose_min_cash):
                    n += 1
                if n:
                    orders.append(["BUY_ANIMAL", animal, n])

        # 2. Seeds — working capital, fastest payback of anything on this list.
        mix = {k: v for k, v in p.crop_mix.items() if v > 0}
        if mix and empty > 0:
            total = sum(mix.values())
            seed_budget = max(0.0, (money - p.cash_floor) * p.seed_budget_frac)
            for crop, w in sorted(mix.items(), key=lambda kv: -kv[1]):
                want = int(empty * w / total) + 1
                have = priv["seeds"].get(crop, 0)
                cost = CROPS[crop]["seed"]
                n = min(want - have, int(seed_budget // cost))
                if n > 0 and afford(n * cost):
                    orders.append(["BUY_SEED", crop, n])
                    seed_budget -= n * cost

        # 3. Feed for animals already owned — starving one writes off $300+.
        need_wheat = (n_animals + n_structs) * p.wheat_reserve_per_animal
        have_wheat = priv["shed"].get("WHEAT", 0)
        if n_animals and need_wheat > have_wheat:
            n = min(need_wheat - have_wheat, 10)
            if afford(n * obs["market"]["prices"]["WHEAT"]):
                orders.append(["BUY_PRODUCT", "WHEAT", n])

        # 4. Hands — spread across turns so HIRE cannot eat every order slot at hour 0.
        if p.hire_max > 0 and hour < 6 and len(orders) < 8:
            n = min(3, p.hire_max - farm["hires_today"], 8 - len(orders))
            for _ in range(max(0, n)):
                if afford(4.0):
                    orders.append(["HIRE"])

        if not p.animals_before_seeds:
            buy_animals()

        # 6. Land — largest and slowest outlay, and it needs *labour* headroom, not just cash.
        #    Measured: buying it with too few hands halves final money (experiments.md E1).
        # Buy land when the land we already own is nearly full *and* the labour force could work
        # more than it holds. The previous form compared `worked` against total labour capacity,
        # which at hire_max=8 is 54 tiles — unreachable when only 25 are unlocked, so the branch
        # was dead and land was never bought at all. Measured symptom: units idle 38-58% of turns.
        if p.buy_land and len(farm["unlocked_quadrants"]) < 4:
            cost = [1000, 2000, 4000][len(farm["unlocked_quadrants"]) - 1]
            unlocked = sum(1 for t in tiles if t != "LOCKED")
            occupied = sum(1 for t in tiles
                           if isinstance(t, dict) and t.get("kind") != "WEED")
            capacity = (1 + p.hire_max) * p.tiles_per_unit
            if (occupied >= p.land_fill_frac * unlocked
                    and capacity > unlocked
                    and afford(cost, p.land_min_cash)):
                orders.append(["BUY_LAND"])

        return orders[:10]

    @staticmethod
    def _estimate_proceeds(item: str, n: int, inv: dict, params: dict | None = None) -> float:
        """Revenue a pending sell will raise, so this turn's buys can budget against it."""
        base = inv[item]
        return float(sum(market_price(item, base + k, params) for k in range(min(n, 200))))

    def _sell_orders(self, priv: dict, inv: dict, day: int, feed_reserve: int,
                     obs: dict | None = None) -> list[list]:
        """Marginal reservation pricing: sell while the *next* unit still clears the reserve.

        With `forecast_weight > 0` the reserve is blended toward the price we expect after the
        opponent's visible supply lands. Holding out for a price their harvest is about to destroy
        is how a static rule loses the race into the good part of the curve (experiments E6).
        """
        p = self.p
        out: list[list] = []
        dump = day >= p.sell_all_after_day
        supply = drain = None
        mparams = obs["market"].get("params") if obs is not None else None
        if obs is not None and p.forecast_weight > 0:
            supply = self.opponent_supply(obs, obs["player"])
            drain = self.town_drain_per_day(obs)
        for item, held in priv["shed"].items():
            if held <= 0 or item not in BASE_PRICE:
                continue
            if item == "WHEAT" and not dump:
                # Must match the buy-side reserve exactly, or the engine sells back the feed it
                # just bought — a churn loop that burns market slots and inflates revenue stats
                # while netting zero.
                held -= feed_reserve
                if held <= 0:
                    continue
            if dump:
                out.append(["SELL", item, held])
                continue
            reserve = p.reserve_frac.get(item, 0.0) * BASE_PRICE[item]
            if supply is not None:
                w = p.forecast_weight
                reserve = ((1 - w) * reserve
                           + w * self.forecast_price(item, inv, supply, drain, mparams))
            n = 0
            cur = inv[item]
            while n < held and market_price(item, cur + n, mparams) >= reserve:
                n += 1
            if n > 0:
                out.append(["SELL", item, n])
        return out

    # ------------------------------------------------------------------- main

    def __call__(self, obs: dict) -> dict:
        player = obs["player"]
        farm = obs["farms"][player]
        priv = obs["private"]
        day, hour = obs["day"], obs["hour"]

        units = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        invs = priv["inventories"]
        tasks = self.build_tasks(farm, priv, day)
        unit_actions = self.assign(units, tasks, invs)

        return {
            "farmer": unit_actions[0],
            "hands": unit_actions[1:],
            "market": self.market(obs, farm, priv, day, hour),
        }


def make_agent(params: Params | None = None):
    """kagsim agents are called once per turn, so the engine keeps its own per-episode state."""
    return Engine(params)
