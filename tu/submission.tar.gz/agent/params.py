"""Tunable knobs for the scripted engine.

This dataclass *is* the vector that T2.1's CEM/CMA-ES optimizes, so every strategic choice the
engine makes should be a field here rather than a constant in the code.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields


@dataclass
class Params:
    # --- cash management -----------------------------------------------------
    # Measured: without a floor the engine spends to $0 on day 0 and never recovers, which
    # invalidated the entire goose experiment (docs/experiments.md E3). Seeds are working capital
    # — running out of cash to buy them costs more than anything else on this list.
    cash_floor: float = 150.0         # never spend below this
    land_min_cash: float = 2500.0     # surplus required *on top of* the quadrant price
    # Measured (E12): a high value silently disables the whole livestock line — `goose_target` has
    # no effect if a bird can never be afforded. The champion uses ~337. Kept inside the search
    # bound in search/space.py, which is also why that bound was cut to 800.
    goose_min_cash: float = 300.0     # surplus required on top of the bird's cost
    seed_budget_frac: float = 0.5     # max share of spendable cash committed to seeds per turn

    # --- land and labour -----------------------------------------------------
    # Measured: buying land *loses* money at every tested mix (docs/experiments.md E1, E6). Melon
    # saturates its own market at ~25 tiles, so extra tiles produce goods that cannot be sold
    # profitably while raising travel from 31% to 58% of every turn. Default off; opt in per config.
    buy_land: bool = False
    land_fill_frac: float = 0.8       # buy the next quadrant once this share of owned land is used
    hire_max: int = 8                 # measured optimum ~8; 12+ bankrupts (fib cost explodes)
    tiles_per_unit: float = 6.0       # standing crops per unit; over-planting just breeds weeds

    # --- crop mix ------------------------------------------------------------
    # Target share of plantable tiles per crop; normalized, so relative weights are what matter.
    crop_mix: dict[str, float] = field(
        default_factory=lambda: {"WHEAT": 1.0, "CARROT": 0.0, "MELON": 0.0,
                                 "TOMATO": 0.0, "STRAWBERRY": 0.0}
    )
    melon_stagger: int = 0            # plant melons in N waves rather than all at once

    # --- animals -------------------------------------------------------------
    # Per-species targets. Cows and sheep were unbuildable until V3 — `BUILD_PASTURE` appeared
    # nowhere in the engine — so they were never rejected on evidence, only never implemented.
    goose_target: int = 0
    cow_target: int = 0
    sheep_target: int = 0
    # Spend priority. A goose bought on day 1 returns ~11x over the season and starts paying on
    # day 4; bought on day 10 it returns ~7x. Seeds currently outrank animals in `Engine.market`,
    # so geese wait for the first melon revenue. This flips that ordering so the compounding asset
    # is funded first — searchable, because the tradeoff against seed throughput is not obvious.
    animals_before_seeds: bool = False
    care: bool = True                 # CARE + daily feed, vs alternate-day feeding
    feed_alternate: bool = False      # feed every other day (incompatible with a care bank)
    wheat_reserve_per_animal: int = 2
    # How many animals one shed trip should carry feed for. Was effectively 1: `per_trip` divided
    # the unfed count across *all* units, so eight units each walked to the shed for a single
    # wheat. A unit carrying N wheat can satisfy N FEED tasks in a row, so this converts N round
    # trips into one. Movement was 62-65% of every turn.
    feed_batch: int = 6
    # How much a priority step is worth in tiles walked. Assignment sorted by (priority, distance),
    # so any higher-priority task anywhere on the farm outranked a neighbouring one — units crossed
    # the map instead of clearing a cluster. 0 = pure nearest-task, large = strict priority.
    priority_weight: float = 0.0  # wheat kept in the shed per animal, for feeding

    # --- market --------------------------------------------------------------
    # Sell a unit only while its marginal price >= reserve_frac * base price.
    reserve_frac: dict[str, float] = field(
        default_factory=lambda: {"WHEAT": 0.0, "CARROT": 0.0, "TOMATO": 0.0,
                                 "STRAWBERRY": 0.0, "MELON": 0.55, "EGG": 0.0,
                                 "MILK": 0.5, "WOOL": 0.5, "FERTILIZER": 0.4}
    )
    sell_all_after_day: int = 28      # dump everything near the end; unsold stock scores nothing

    # --- market timing (T1.3) -------------------------------------------------
    # The opponent's tiles are public, so their crop counts and planting days give their harvest
    # dates and incoming supply (PLAN.md 2.5). Blend the static reserve with the price we expect
    # to see once that supply lands: 0 = ignore the opponent, 1 = price purely off the forecast.
    # Measured joint optimum (docs/experiments.md E7): w=1.0, horizon=10. Horizon 10 is melon's
    # plant-to-harvest cycle, so the forecast sees exactly one full wave.
    #
    # These two knobs interact strongly and coordinate-wise tuning misleads: at horizon 4 the best
    # weight was 0.6 and w=1.0 was the *worst* config of all; at horizon 10 w=1.0 is the best.
    # A mis-tuned forecast is also worse than none — several settings lose to forecast_weight=0.
    # T2.1 must search jointly.
    #
    # w=1.0 discards the static reserve entirely, leaving one interpretable rule: sell while the
    # marginal price is at least what the price is expected to be once the opponent's visible
    # supply lands.
    forecast_weight: float = 1.0
    forecast_horizon: int = 10        # days of opponent supply to look ahead

    # --- harvest timing ------------------------------------------------------
    harvest_early: bool = False       # harvest at first_yield_day instead of at max yield

    def to_vector(self) -> list[float]:
        """Flatten for black-box search (T2.1)."""
        out: list[float] = []
        for f in fields(self):
            v = getattr(self, f.name)
            if isinstance(v, dict):
                out.extend(float(v[k]) for k in sorted(v))
            else:
                out.append(float(v))
        return out
